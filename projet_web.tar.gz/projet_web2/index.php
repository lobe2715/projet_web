<?php include('includes/header.php');?>
<h1> Bienvenue sur le site de formation musical !</h1>
<?php
echo $_SESSION['user_nom'];
echo ' ';
echo $_SESSION['user_prenoml'];
?>
<?php include('includes/footer.php');?>
