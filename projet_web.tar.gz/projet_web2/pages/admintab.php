<?php include('../includes/header.php');?>

<div class="g2">
    <?php include('../includes/tab_admin.php'); ?>
</div>

<?php include('../includes/footer.php');?>
