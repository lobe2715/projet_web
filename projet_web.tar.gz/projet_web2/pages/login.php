<?php
include('../includes/header.php');?>
 <div class="formulaire">
    <button class="choix" type="button" onclick="register()">Enregistrer</button>
    <button class="choix" type="button" onclick="login()">Connection</button>
    <form id="register" action="../includes/ajouter_profil.php" method="post" class="register">
      <p>S'enregistrer:</p>
      <input align="center" type="text" placeholder="Nom:" name="Nom">
      <input type="text" placeholder="Prenom:" name="Prenom">
      <input type="text" pattern=".*@.*\..*" placeholder="Address Email:" name="Adresse">
      <input type="password" placeholder="Mot de passe:" name="Mdp">
      <input type="tel" pattern="[0-9]{10}" placeholder="Telephone:" name="Tel"><br><br>
          <button type="submit">S'enregistrer</button>
    </form>
    <form id="login" action="../includes/log.php" method="post" class="login">
      <p>Connection:</p>
      <input type="text" placeholder="Address Email:" name="Mail"> 
      <input type="password" placeholder="Mot de passe:" name="Mdp"><br><br>
          <button type="submit" >Connection</button>
      </form>
      <a href="../includes/deconnexion.php"> <button> Déconnexion</button></a>
  </div>
</body>
<?php include('../includes/footer.php');?>
