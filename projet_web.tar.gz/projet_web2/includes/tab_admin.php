<?php include('connex.inc.php');
$pdo = connexion('gs05790v');
try{

    $req= $pdo ->prepare("SELECT * FROM PROFILS");
    $req->execute();
    $user = $req->fetch(PDO::FETCH_ASSOC);
}
echo "<table>";
echo "<tr><th>nom</th><th>prenom</th><th>adresse</th><th>classe</th><th>rang</th></tr>";
foreach ($user as $users) {
    echo "<tr>";
    echo "<td>" . $users['nom'] . "</td>";
    echo "<td>" . $users['prenom'] . "</td>";
    echo "<td>" . $users['adresse'] . "</td>";
    echo "<td>" . $users['classe'] . "</td>";
    echo "<td>" . $users['rang'] . "</td>";
    echo "<td><form method='post'><input type='hidden' name='id' value='" . $users['adresse'] . "'><input type='submit' name='suppr' value='Supprimer'></form></td>";
    echo "</tr>";
}
echo "</table>";
?>
