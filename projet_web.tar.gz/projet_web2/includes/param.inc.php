<?php
define("HOTE", "webetu.univ-st-etienne.fr"); /*adresse du serveur */
define("UTILISATEUR", "gs05790v"); /* nom d'utilisateur */
define("PASSE", "CH9LF7BW"); /* mot de passe */
?>
