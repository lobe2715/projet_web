<?php
session_start();
include('connex.inc.php');
include('liste_cours.php');
include('liste_court_niveau.php');
$pdo=connexion('gs05790v');
?>

<!DOCTYPE html>
<html lang=”fr”>

<head>
    <meta charset=”utf-8”>
    <title>Accueil</title>
    <link rel="icon" type="image/svg+xml" href="/../assets/images/logos.ico" sizes="64x64">
        <link  href="../assets/css/exemple_cours.css" rel="stylesheet" >
            <script src="../assets/js/exemple_coursjs.js"></script>
            <script src="../assets/js/loginjs.js"></script>
             <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
            </head>
            <body>
                <header>
                    <div><img class="logo" src="../assets/images/logo.png">
                        <ul class="menu">
                        <?php
                        if (file_exists('../index.php')){
                            $accueil = '../index.php';
                        }
                        else{
                            $accueil ='index.php';
                        }
                        ?>
                            <li><a href="<?php echo $accueil; ?>">Accueil</a></li>
                            <li class="sousmenu">Mes Cours
                                <ul class="niveau2">
                                <?php
                                if(isset($_SESSION['user_classe'])){
                                        liste_niveau_cours($pdo);
                                }
                                ?>
                                </ul>
                            </li>
                            <li>Information</li>
                            <li class="sousmenu">Mon Profil
                                <ul class="niveau2">
                                    <li>Mon compte</li>
                                    <li>Mes information</li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                      <?php
                        if (file_exists('pages')){
                            $profil = '/pages/login.php';
                        }
                        else{
                            $profil ='login.php';
                        }
                        ?>
                    <a href="<?php echo $profil; ?>"><img class="profil" src="../assets/images/profil-de-lutilisateur.png"></a>

                    </header>
        
