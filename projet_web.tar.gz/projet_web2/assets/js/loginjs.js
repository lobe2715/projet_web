function register(){
    document.getElementById("register").style.display = "inline-block";
    document.getElementById("login").style.display = "none";
}

function login(){
    document.getElementById("login").style.display = "inline-block";
    document.getElementById("register").style.display = "none";
}
